import React from "react";
import Component5 from "./Component5";

function Component4() {
	return (
		<div>
			<Component5 />
		</div>
	);
}

export default Component4