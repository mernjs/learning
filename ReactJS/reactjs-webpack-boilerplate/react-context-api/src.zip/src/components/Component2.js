import React from "react";
import Component3 from "./Component3";

function Component2() {
	return (
		<div>
			<Component3 />
		</div>
	);
}

export default Component2