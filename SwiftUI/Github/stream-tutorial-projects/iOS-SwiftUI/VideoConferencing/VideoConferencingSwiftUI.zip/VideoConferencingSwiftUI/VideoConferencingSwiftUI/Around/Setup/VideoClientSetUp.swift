
import SwiftUI
import StreamVideo
import StreamVideoSwiftUI

struct VideoClientSetUp: View {
    @State var call: Call
    @ObservedObject var state: CallState
    @State var callCreated: Bool = false

    private var client: StreamVideo
    
    private let apiKey: String = "mmhfdzb5evj2" // The API key can be found in the Credentials section
    private let userId: String = "4-LOM" // The User Id can be found in the Credentials section
    private let token: String = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiNC1MT00iLCJpc3MiOiJwcm9udG8iLCJzdWIiOiJ1c2VyLzQtTE9NIiwiaWF0IjoxNjk1NjIyMzExLCJleHAiOjE2OTYyMjcxMTZ9.DN1WAtEBV_Q0dhTyGh9DjoxxftU754Q-Raih4UYHM3M" // The Token can be found in the Credentials section
    private let callId: String = "yLOzy1KS2tXA" // The CallId can be found in the Credentials section

    init() {
        let user = User(
            id: userId,
            name: "Martin", // name and imageURL are used in the UI
            imageURL: .init(string: "https://getstream.io/static/2796a305dd07651fcceb4721a94f4505/a3911/martin-mitrevski.webp")
        )

        // Initialize Stream Video client
        self.client = StreamVideo(
            apiKey: apiKey,
            user: user,
            token: .init(stringLiteral: token)
        )

        // Initialize the call object
        let call = client.call(callType: "default", callId: callId)

        self.call = call
        self.state = call.state
    }

    var body: some View {
       
            VStack {
                if callCreated {
                    Text("Meeting Call \(call.callId) has \(call.state.participants.count) participant")
                        .font(.system(size: 30))
                        .foregroundColor(.blue)
                } else {
                    VStack {
                        ProgressView()
                        Text("loading...")
                    }
                }
            }.onAppear {
                Task {
                    guard !callCreated else { return }
                    try await call.join(create: true)
                    callCreated = true
                }
           
        }
    }
}
