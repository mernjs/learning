//
//  HTabView.swift
//  TikTokCloneSwiftUI
//
//  Created by Amos Gyamfi on 31.5.2024.
//

import SwiftUI

struct HTabView: View {
    var body: some View {
        TabView {
            ZStack {
                FirstVideoView()
                HStack {
                    Spacer()
                    ReactionButtons1View()
                }
                .frame(width: UIScreen.main.bounds.width)
            }
            
            ZStack {
                SecondVideoView()
                HStack {
                    Spacer()
                    ReactionButtons2View()
                }
                .frame(width: UIScreen.main.bounds.width)
            }
            
            ZStack {
                ThirdVideoView()
                HStack {
                    Spacer()
                    ReactionButtons3View()
                }
                .frame(width: UIScreen.main.bounds.width)
            }
            
            ZStack {
                SelfieVideoView()
                HStack {
                    Spacer()
                    ReactionButtons4View()
                }
                .frame(width: UIScreen.main.bounds.width)
            }
            
            ZStack {
                FireworksVideoView()
                HStack {
                    Spacer()
                    ReactionButtons4View()
                }
                .frame(width: UIScreen.main.bounds.width)
            }
        }
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
        .ignoresSafeArea()
    }
    
    
}

#Preview {
    HTabView()
}
