//
//  EffectsButtonView.swift
//  TikTokCloneSwiftUI
//
//  Created by Amos Gyamfi on 2.6.2024.
//

import SwiftUI

struct EffectsButtonView: View {
    var body: some View {
        VStack {
            Image(.effects)
                .resizable()
                .frame(width: 48, height: 48)
                .cornerRadius(8)
            
            Text("Effects")
        }
    }
}

#Preview {
    EffectsButtonView()
        .preferredColorScheme(.dark)
}
