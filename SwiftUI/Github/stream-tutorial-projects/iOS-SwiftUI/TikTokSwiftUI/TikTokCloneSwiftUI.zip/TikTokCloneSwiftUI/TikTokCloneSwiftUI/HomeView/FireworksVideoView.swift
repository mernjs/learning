//
//  FireworksVideoView.swift
/*import SwiftUI
 import AVFoundation
 import AVKit
 
 struct FireworksVideoView: View {
 @State var player = AVPlayer()
 let avPlayer = AVPlayer(url: Bundle.main.url(forResource: "fireworks", withExtension: "mp4")!)
 
 var body: some View {
 ZStack {
 VideoPlayer(player: avPlayer)
 .scaledToFill()
 .ignoresSafeArea()
 .onAppear {
 avPlayer.play()
 avPlayer.actionAtItemEnd = .none
 NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: avPlayer.currentItem, queue: .main) { (_) in
 avPlayer.seek(to: .zero)
 avPlayer.play()
 }
 }
 }
 }
 }
 #Preview {
 FireworksVideoView()
 }
 */

//
//  FireworksVideoView.swift
//
import SwiftUI
import AVFoundation
import AVKit

struct FireworksVideoView: View {
    @State private var player = AVPlayer()
    @State private var loopCount = 0
    private let maxLoops = 2
    private let avPlayer = AVPlayer(url: Bundle.main.url(forResource: "fireworks", withExtension: "mp4")!)
    
    var body: some View {
        ZStack {
            VideoPlayer(player: avPlayer)
                .scaledToFill()
                .ignoresSafeArea()
                .onAppear {
                    avPlayer.play()
                    avPlayer.actionAtItemEnd = .none
                    NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: avPlayer.currentItem, queue: .main) { _ in
                        loopCount += 1
                        if loopCount < maxLoops {
                            avPlayer.seek(to: .zero)
                            avPlayer.play()
                        } else {
                            NotificationCenter.default.removeObserver(self, name: .AVPlayerItemDidPlayToEndTime, object: avPlayer.currentItem)
                        }
                    }
                }
        }
    }
}

#Preview {
    FireworksVideoView()
}
